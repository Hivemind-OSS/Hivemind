"""hive-edge Claude-Code hook adapters — the ONLY Claude-Code-aware module.

Four thin adapters over the SAME engine cores the CLI verbs use (`_mint_core`,
`_subgraph_fp_core`, `_verify_core`, `_wd_state` in `hive_edge/cli.py`); a hook adds only the
TRIGGER and the Claude-Code JSON envelope — never new knowledge. The moment a hook reimplements mint/verify/work-delta, Claude
Code forks from every other harness, so this module carries no engine computation of its own: it
parses the CC event, delegates to a core, and shapes the result.

Every handler returns a dict to emit or `None` to emit nothing (passthrough), and
defensive-parses its payload (coerce shape BEFORE `.get()` — a non-dict payload / tool_input /
tool_response yields `None`, never a raise). The dispatch (`cli._cmd_hook`) drives an
ALWAYS-exit-0 contract: a hook fault must never block a Claude-Code step.
"""
from __future__ import annotations

import json

from hive_edge import cli

# The self-capture trigger fed to the agent as a Stop block reason, and the gentle Stop-echo for a
# clean/unchanged turn — ported from the shipped stop-capture hook (the BUG-017 enforcement text),
# VERBATIM except the mint clause, which now names the shipped `hive-edge mint` command (the retired
# mint_fp.py helper is replaced by the CLI verb). The capture discipline itself is single-sourced in
# the agent's always-in-context HIVEMIND-RULES block; this reason is a terse trigger pointing there,
# never a restatement.
CAPTURE_PROMPT: str = (
    "[hivemind self-capture] Work happened since the last checkpoint. Apply the "
    "task-end capture discipline from your HIVEMIND-RULES block: sweep the session "
    "and capture EACH durable lesson that clears the noise floor as its OWN "
    "single-pointed hive_capture — never bundled; usually zero or one entry.\n"
    "Shape: text = WHAT + WHERE (path/file.py:symbol, in the text itself) + WHY; "
    "anchor = that same file:symbol; kind: bug, gotcha, convention, design_choice, "
    "contract, dead_end, env_fact, note; polarity dont/do/neutral; meta = the JSON "
    "printed by `hive-edge mint --anchor \"<file:symbol>\"` ({} -> omit).\n"
    "If nothing clears the bar, capture NOTHING and finish — declining is "
    "compliance. Never hive_write autonomously from this hook; when a lesson is "
    "load-bearing and must serve NOW, ask the operator to approve a hive_write."
)

GENTLE_NUDGE: str = (
    "[hivemind] Capture any durable insight from this turn (design choice + where, "
    "gotcha, dead-end) with hive_capture — no need to ask; bug lessons (landed fix, "
    "or truly open bug) -> ask your approver for a hive_write."
)


def read_event(raw: str) -> dict:
    """Defensive stdin parse: a dict or `{}` — never a raise, never a non-dict (the
    MCP-loop-crash lesson: coerce the envelope shape before any `.get()`)."""
    try:
        data = json.loads(raw or "{}")
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


# ── PreToolUse: mint the fp at capture (updatedInput) ───────────────────────────

def hook_pre_capture(payload: dict, repo_root: str | None) -> dict | None:
    """PreToolUse on `mcp__hive__hive_capture`. When the capture carries an `anchor`, mint the
    fingerprint UNION — `combdrift/fp` (interface shape) ∪ `matrix/subgraph_fp` (dependency
    neighborhood) — and MERGE the missing keys into meta, per-key idempotent: a key already
    present in the incoming meta is NEVER overwritten (its core is not even recomputed); return
    the CC `updatedInput` rewrite. A prose anchor mints neither key. Any non-mint path (no
    anchor / nothing missing / nothing minted / malformed) -> None (emit nothing =
    passthrough)."""
    if not isinstance(payload, dict):
        return None
    tool_input = payload.get("tool_input")
    if not isinstance(tool_input, dict):
        return None
    anchor = tool_input.get("anchor")
    if not isinstance(anchor, str) or not anchor.strip():
        return None
    meta = tool_input.get("meta")
    if not isinstance(meta, dict):
        meta = {}
    minted: dict = {}
    if "combdrift/fp" not in meta:                   # already minted -> per-key nothing to add
        minted.update(cli._mint_core(repo_root, anchor))
    if "matrix/subgraph_fp" not in meta:
        minted.update(cli._subgraph_fp_core(repo_root, anchor))
    if not minted:
        return None
    # // marker: REPLACING meta (dropping existing keys) instead of MERGING it is a mutation.
    updated = {**tool_input, "meta": {**meta, **minted}}
    return {"hookSpecificOutput": {"hookEventName": "PreToolUse", "updatedInput": updated}}


# ── PostToolUse: verify recalled hits (additionalContext) ───────────────────────

def hook_post_recall(payload: dict, repo_root: str | None) -> dict | None:
    """PostToolUse on `mcp__hive__hive_recall`. Verify each anchored hit against `repo_root` via
    the shared verify core and ANNOTATE — never rewrite — the served recall: a STALE hit relays
    the notice the core composed (verdict + reason + remediation + delta, with the radius line
    appended when the dependency neighborhood ALSO moved); a CURRENT hit whose stored subgraph
    fp no longer matches relays the ONE advisory line (the core's RADIUS_NOTICE — the memory
    may still be correct). The persistent graph is loaded ONCE per recall — iff any hit carries
    a subgraph fp — and passed down per hit. `unverifiable` / all-current -> None."""
    if not isinstance(payload, dict):
        return None
    hits = _recall_hits(payload.get("tool_response"))
    graph = None
    # // marker: loading the graph PER HIT (dropping this once-per-recall load) is a mutation.
    if repo_root is not None and any(
            sfp is not None and cli._subgraph_fp_version(sfp) == cli.SUBGRAPH_FP_VERSION
            for _, _, sfp, _ in hits):
        graph = cli._load_graph(repo_root)
    consumer = None
    # marker: resolving the consumer branch PER HIT (or unconditionally) is a mutation —
    # ONE resolution per recall, and only when a hit actually carries a branches token
    # (the graph-load gating idiom: no token, no git call).
    if any(branches is not None for _, _, _, branches in hits):
        consumer = cli._current_branch(repo_root)
    notices = []
    for anchor, fp, sfp, branches in hits:
        # A failed load (graph None) drops the radius tier for this recall — the key is
        # omitted downstream, and the load fault is never re-paid per hit.
        result = cli._verify_core(repo_root, anchor, fp,
                                  sfp if graph is not None else None, graph=graph,
                                  branches=branches, consumer_branch=consumer)
        verdict = result.get("verdict")
        # Relay STALE hits (they carry remediation), BRANCH_SCOPED hits (the one-line
        # off-branch advisory), and CURRENT hits whose neighborhood moved (advisory only);
        # `unverifiable` and quiet-current hits add no actionable signal -> nothing to
        # annotate.
        if (verdict == "stale" or verdict == "branch_scoped"
                or (verdict == "current" and result.get("radius") == "changed")):
            notices.append(_relay_notice(anchor, result))
    if not notices:
        return None
    # // marker: REWRITING the served recall instead of ANNOTATING (additionalContext) is a mutation.
    return {"hookSpecificOutput": {"hookEventName": "PostToolUse",
                                   "additionalContext": "\n".join(notices)}}


def _recall_hits(tool_response: object
                 ) -> list[tuple[str, str | None, str | None, str | None]]:
    """Extract `[(anchor, combdrift_fp|None, subgraph_fp|None, branches|None)]` from a recall
    tool_response, defensively — handles the already-parsed payload
    (`{"reference_context": [...]}`) and the raw MCP CallToolResult
    (`{"content": [{"text": "<json>"}]}`). Any shape surprise -> []."""
    payload = _recall_payload(tool_response)
    if payload is None:
        return []
    hits = payload.get("reference_context")
    if not isinstance(hits, list):
        return []
    out = []
    for h in hits:
        if not isinstance(h, dict):
            continue
        anchor = h.get("anchor")
        if not isinstance(anchor, str) or not anchor.strip():
            continue
        meta = h.get("meta") if isinstance(h.get("meta"), dict) else {}
        fp = meta.get("combdrift/fp")
        sfp = meta.get("matrix/subgraph_fp")
        branches = meta.get("git/branches")
        out.append((anchor, fp if isinstance(fp, str) else None,
                    sfp if isinstance(sfp, str) else None,
                    branches if isinstance(branches, str) else None))
    return out


def _recall_payload(tool_response: object) -> dict | None:
    """The recall payload dict, from a tool_response of either shape, or None."""
    if not isinstance(tool_response, dict):
        return None
    if isinstance(tool_response.get("reference_context"), list):
        return tool_response
    content = tool_response.get("content")
    if isinstance(content, list):
        for item in content:
            if isinstance(item, dict) and isinstance(item.get("text"), str):
                try:
                    parsed = json.loads(item["text"])
                except Exception:
                    continue
                if isinstance(parsed, dict):
                    return parsed
    return None


def _relay_notice(anchor: str, result: dict) -> str:
    """Relay ONE verify result verbatim, never re-derived here. A `current` anchor is relayed
    only for its changed neighborhood: the single advisory line (`RADIUS_NOTICE`, single-sourced
    in the core). A `branch_scoped` anchor relays the core's ONE-line off-branch notice —
    NEVER the remediation block (scoped-to-another-line is not stale). A stale anchor keeps
    the full notice — verdict + machine reason, the remediation the core composed, the
    fingerprint delta when present — with the radius line APPENDED when the neighborhood
    also moved."""
    if result.get("verdict") == "branch_scoped":
        # marker: attaching REMEDIATION_TEXT (or any retirement option) to a
        # branch_scoped notice is a mutation — ONE advisory line, nothing else.
        return f"[hivemind recall] anchor {anchor!r}: {result.get('notice')}"
    if result.get("verdict") == "current":
        return f"[hivemind recall] anchor {anchor!r}: {cli.RADIUS_NOTICE}."
    lines = [f"[hivemind recall] anchor {anchor!r}: {result.get('verdict')} "
             f"({result.get('reason')})."]
    remediation = result.get("remediation")
    if remediation:
        lines.append(remediation)
    delta = result.get("delta")
    if isinstance(delta, dict):
        lines.append(f"delta: old={delta.get('old_token')} new={delta.get('new_token')} "
                     f"breaking={delta.get('breaking')}")
    if result.get("radius") == "changed":
        lines.append(f"radius: {cli.RADIUS_NOTICE}.")
    return "\n".join(lines)


# ── SessionStart / Stop: the work-delta baseline (BUG-017 three-valued) ─────────

def hook_session_start(payload: dict) -> dict | None:
    """SessionStart. Thin adapter over the work-delta BASELINE core: record "measure work from
    here" (the git-porcelain hash keyed by (session_id, repo_root)) and emit NOTHING — baseline
    mode is silent, exactly like the shipped `--baseline` mode. A git fault invents no baseline
    (fail-open)."""
    if not isinstance(payload, dict) or not payload:  # non-dict / empty envelope -> passthrough
        return None
    state, current, state_path = cli._wd_state(cli._resolve_repo(None),
                                               payload.get("session_id"))
    if state == "git_fault":
        return None
    cli._record_hash(state_path, current)            # overwrite any prior checkpoint, silently
    return None


def hook_stop(payload: dict) -> dict | None:
    """Stop. Thin adapter over the work-delta CHECK core with the BUG-017 three-valued semantics
    VERBATIM:
      - `no_baseline` (missing) -> RECORD the observation + a GENTLE nudge (additionalContext),
        NEVER block — unattributable pre-existing dirt is not this turn's work;
      - `unchanged` (incl. a recorded-clean `""` baseline) -> emit nothing;
      - `changed` (a checkpoint delta) -> `{"decision": "block", "reason": CAPTURE_PROMPT}`, the
        CURRENT shipped enforcement (NOT softened to additionalContext), advancing the checkpoint so
        a subsequent unchanged Stop does not re-block.
    `stop_hook_active` is the absolute re-entry guard. Every path exits 0 — `decision: block` and
    the process exit code are orthogonal; this handler NEVER causes exit 2."""
    if not isinstance(payload, dict) or not payload:  # non-dict / empty envelope -> passthrough
        return None
    if payload.get("stop_hook_active"):              # re-entry guard — absolute
        return None
    state, current, state_path = cli._wd_state(cli._resolve_repo(None),
                                               payload.get("session_id"))
    if state == "git_fault":
        return None
    if state == "no_baseline":
        cli._record_hash(state_path, current)        # this observation becomes the baseline
        # // marker: BLOCKING on a missing baseline is the BUG-017 regression.
        return {"hookSpecificOutput": {"hookEventName": "Stop",
                                       "additionalContext": GENTLE_NUDGE}}
    if state == "unchanged":
        return None
    cli._record_hash(state_path, current)            # advance the checkpoint past this delta
    return {"decision": "block", "reason": CAPTURE_PROMPT}
