"""Hive-edge — the single installable edge CLI for the Hivemind fleet.

Fronts two workspace-member engines behind one console script and one version:
  - combdrift : node-level contract-drift / symbol-existence verifier
  - matrix    : AST-only code-structure engine + blast radius

`__version__` is the ONE workspace lockstep version: the hive-edge, matrix, and comb-drift
distributions all ship this exact version, bumped together once per release (the guard test in
tests/edge/test_cli.py enforces equality across every version site by reading the sources).
It also drives the hivemind contract's MIN_EDGE_VERSION floor, which may never exceed it.
"""
__version__ = "0.8.0"
